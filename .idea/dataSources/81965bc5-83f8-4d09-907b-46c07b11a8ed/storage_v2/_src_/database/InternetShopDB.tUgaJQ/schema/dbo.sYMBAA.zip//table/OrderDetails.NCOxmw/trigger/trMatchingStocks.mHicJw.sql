CREATE TRIGGER trMatchingStocks
ON OrderDetails
FOR INSERT, DELETE, UPDATE
AS
	IF @@ROWCOUNT = 0
		RETURN
	
	SET NOCOUNT ON

	-- Change qty of product in stocks when changed qty of same products if order
	IF EXISTS (SELECT 1 FROM inserted) AND EXISTS (SELECT 1 FROM deleted)
		BEGIN
			IF NOT UPDATE(Qty)
				RETURN
			UPDATE Stocks
			SET Qty = s.Qty - (i.Qty - d.Qty)
			FROM Stocks s JOIN
			(SELECT ProductID, SUM(Qty) Qty FROM deleted GROUP BY ProductID) d
			ON s.ProductID = d.ProductID
			JOIN
			(SELECT ProductID, SUM(Qty) Qty FROM inserted GROUP BY ProductID) i
			ON s.ProductID = i.ProductID
		END

	-- Increase qty of product in stocks if order deletes
	ELSE IF NOT EXISTS (SELECT 1 FROM inserted) AND EXISTS (SELECT 1 FROM deleted)
		BEGIN
			UPDATE Stocks
			SET Qty = s.Qty + d.Qty
			FROM Stocks s JOIN
			(SELECT ProductID, SUM(Qty) Qty FROM deleted GROUP BY ProductID) d
			ON s.ProductID = d.ProductID
		END

	-- Decrease qty of product in stocks when add product to order
	ELSE IF EXISTS (SELECT 1 FROM inserted) AND NOT EXISTS (SELECT 1 FROM deleted)
		BEGIN
			UPDATE Stocks
			SET Qty = s.Qty - i.Qty
			FROM Stocks s JOIN
			(SELECT ProductID, SUM(Qty) Qty FROM inserted GROUP BY ProductID) i
			ON s.ProductID = i.ProductID
		END
go

