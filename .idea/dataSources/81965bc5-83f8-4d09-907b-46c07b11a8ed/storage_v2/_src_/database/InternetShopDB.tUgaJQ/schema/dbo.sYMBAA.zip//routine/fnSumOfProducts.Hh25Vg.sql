CREATE FUNCTION fnSumOfProducts()
RETURNS INT
BEGIN
	DECLARE @sum INT = 0
	DECLARE @addend INT = 0
	DECLARE @productQuantityCur CURSOR

	SET @productQuantityCur = CURSOR
	FOR SELECT Qty FROM Stocks
	OPEN @productQuantityCur
	WHILE @@FETCH_STATUS = 0
		BEGIN
		FETCH NEXT FROM @productQuantityCur INTO @addend
		SET @sum = @sum + @addend
		END
	CLOSE @productQuantityCur
	DEALLOCATE @productQuantityCur
	RETURN @sum
END
go

