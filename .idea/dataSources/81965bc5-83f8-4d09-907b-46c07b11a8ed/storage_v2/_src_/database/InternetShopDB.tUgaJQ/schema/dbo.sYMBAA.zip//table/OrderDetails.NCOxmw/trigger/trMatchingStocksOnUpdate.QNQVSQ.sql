
-- Change qty of product in stocks when changed qty of same products if order
CREATE TRIGGER trMatchingStocksOnUpdate
ON OrderDetails
FOR UPDATE
AS
	-- For situations like that:
	-- INSERT INTO OrderDetails
	-- SELECT * FROM SomeEmptyTable WHERE
	IF @@ROWCOUNT = 0
		RETURN

	IF NOT UPDATE(Qty)
		RETURN

	SET NOCOUNT ON

	UPDATE Stocks
	SET Qty = s.Qty - (i.Qty - d.Qty)
	FROM Stocks s JOIN
	(SELECT ProductID, SUM(Qty) Qty FROM deleted GROUP BY ProductID) d
	ON s.ProductID = d.ProductID
	JOIN
	(SELECT ProductID, SUM(Qty) Qty FROM inserted GROUP BY ProductID) i
	ON s.ProductID = i.ProductID
go

