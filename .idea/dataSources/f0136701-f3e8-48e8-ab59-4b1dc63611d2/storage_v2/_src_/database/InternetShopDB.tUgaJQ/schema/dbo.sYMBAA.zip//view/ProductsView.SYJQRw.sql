CREATE VIEW dbo.ProductsView
AS
SELECT        Products.ID, Products.Name, ProductDetails.Color, ProductDetails.Description, Stocks.Qty
FROM            ProductDetails INNER JOIN
                         Products ON ProductDetails.ID = Products.ID INNER JOIN
                         Stocks ON Products.ID = Stocks.ProductID

go

