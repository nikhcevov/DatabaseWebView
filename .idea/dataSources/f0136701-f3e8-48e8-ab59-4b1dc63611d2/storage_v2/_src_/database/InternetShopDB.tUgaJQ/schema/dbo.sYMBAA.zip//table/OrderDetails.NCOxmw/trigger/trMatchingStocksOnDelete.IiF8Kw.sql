CREATE TRIGGER trMatchingStocksOnDelete
ON OrderDetails
FOR DELETE
AS
	-- For situations like that:
	-- INSERT INTO OrderDetails
	-- SELECT * FROM SomeEmptyTable WHERE
	IF @@ROWCOUNT = 0
		RETURN

	SET NOCOUNT ON

	UPDATE Stocks
	SET Qty = s.Qty + d.Qty
	FROM Stocks s JOIN
	(SELECT ProductID, SUM(Qty) Qty FROM deleted GROUP BY ProductID) d
	ON s.ProductID = d.ProductID
go

