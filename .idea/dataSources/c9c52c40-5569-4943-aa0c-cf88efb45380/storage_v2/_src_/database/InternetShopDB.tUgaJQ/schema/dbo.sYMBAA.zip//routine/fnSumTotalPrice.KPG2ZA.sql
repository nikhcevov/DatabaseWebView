
-- Get sum of orders for period
-- 2 parameters: start date and end date of period
CREATE FUNCTION fnSumTotalPrice (@DateFrom date, @DateTo date)
returns money
AS 
BEGIN
	RETURN 
	(
		SELECT SUM(TotalPrice) FROM Orders o JOIN 
					OrderDetails od ON od.OrderID = o.ID
		WHERE OrderDate BETWEEN @DateFrom AND @DateTo
	)
END
go

