-- Get ID, full name, post and sum of sells for an employee
CREATE VIEW EmployeeStatistics
AS
	SELECT e.ID, e.FName + ' ' + e.MName + ' ' + e.LName Employee, e.Post, 
	(SELECT SUM(TotalPrice) FROM OrderDetails od JOIN Orders o ON o.ID = od.OrderID
		WHERE o.EmployeeID = e.ID) TotalSold
	FROM Employees e
go

