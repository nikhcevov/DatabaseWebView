CREATE PROCEDURE spChangeProductCount(@nameOfProduct VARCHAR(35), @newQuantity INT)
AS
	SET NOCOUNT ON
	BEGIN
		UPDATE Stocks 
		SET Qty = @newQuantity
		FROM Stocks s JOIN Products p
		ON s.ProductID = p.ID
		WHERE p.Name = @nameOfProduct
	END
go

