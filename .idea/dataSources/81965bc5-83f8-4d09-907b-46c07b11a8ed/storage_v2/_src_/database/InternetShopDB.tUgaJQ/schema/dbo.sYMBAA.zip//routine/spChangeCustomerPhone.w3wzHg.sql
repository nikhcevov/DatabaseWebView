CREATE PROCEDURE spChangeCustomerPhone
	@prev_phone CHAR(12),
	@new_phone CHAR(12)
AS
	SET NOCOUNT ON
	BEGIN
		UPDATE Customers 
		SET Phone = @new_phone 
		WHERE Phone = @prev_phone
	END

--- Test
EXEC spChangeCustomerPhone @prev_phone = '(963)4569385', @new_phone = '(921)3019913'
EXEC spChangeCustomerPhone @prev_phone = '(921)3019913', @new_phone = '(963)4569385'

SELECT * FROM Customers
go

