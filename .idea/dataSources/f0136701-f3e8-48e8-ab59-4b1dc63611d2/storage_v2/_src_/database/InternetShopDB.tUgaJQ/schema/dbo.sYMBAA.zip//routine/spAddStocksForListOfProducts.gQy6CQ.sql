CREATE PROCEDURE spAddStocksForListOfProducts
	@String VARCHAR(300),
	@Qty INT
AS
	BEGIN
		DECLARE @Delimeter NVARCHAR(1) = ';'
		DECLARE @Pos int = CHARINDEX(@Delimeter, @String)
		DECLARE @Name NVARCHAR(300)
		WHILE @String != ''
			BEGIN 
				SET @Name = SUBSTRING(@String, 1, @Pos-1)
				SET @String = REPLACE(@String, CONCAT(@Name, @Delimeter), '')
				SET @Pos = CHARINDEX(@Delimeter, @String)
				EXEC spChangeProductCount @nameOfProduct = @Name, @newQuantity = @Qty
			END
	END
go

