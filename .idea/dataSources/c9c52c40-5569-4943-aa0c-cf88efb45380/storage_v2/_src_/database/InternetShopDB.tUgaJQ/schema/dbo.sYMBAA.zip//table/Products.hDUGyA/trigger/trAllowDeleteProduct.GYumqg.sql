CREATE TRIGGER trAllowDeleteProduct
ON Products
INSTEAD OF DELETE
AS
	IF @@ROWCOUNT = 0
		RETURN

	SET NOCOUNT ON

	IF EXISTS (SELECT 1 FROM OrderDetails od
						JOIN deleted d
						ON od.ProductID = d.ID)
		RAISERROR('Cannot delete product (Active orders)', 10, 1)
	ELSE IF EXISTS (SELECT 1 FROM Stocks s
						JOIN deleted d
						ON s.ProductID = d.ID
						WHERE s.Qty <> 0)
		RAISERROR('Cannot delete product (Stocks isn`t empty)', 10, 1)
	ELSE 
		DELETE Products WHERE ID IN (SELECT ID FROM deleted)
go

