-- Get all info about employees
CREATE VIEW EmployeeDate
AS
	SELECT e.ID, e.FName + ' ' + e.MName + ' ' + e.LName Employee,
		e.Post, e.Salary, e.PriorSalary, ei.Phone, ei.Adress, ei.BirthDate, ei.MaritalStatus FROM Employees e LEFT JOIN
			EmployeesInfo ei ON e.ID = ei.ID
go

