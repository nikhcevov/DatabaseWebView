CREATE PROCEDURE spAddProduct
	@Name nvarchar(50),
	@Color nchar(20) = NULL,
	@Description nvarchar(max) = null,
	@Qty int  = 0
AS
	SET NOCOUNT ON

	DECLARE @Id int

	INSERT Products
	VALUES
	(@Name)

	SET @Id = @@IDENTITY

	INSERT ProductDetails
	VALUES
	(@Id, @Color, @Description)

	INSERT Stocks
	VALUES
	(@Id, @Qty)
go

