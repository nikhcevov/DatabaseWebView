

CREATE VIEW dbo.TotalShopIncome
AS
SELECT SUM(OrderDetails.TotalPrice) AS Total
FROM OrderDetails
go

