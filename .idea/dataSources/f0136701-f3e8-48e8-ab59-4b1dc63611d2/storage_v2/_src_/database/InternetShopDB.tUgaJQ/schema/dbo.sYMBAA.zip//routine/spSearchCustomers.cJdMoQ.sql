CREATE PROCEDURE spSearchCustomers
	@LName nvarchar(20) = '%',
	@City nvarchar(20) = '%'
AS
	SET NOCOUNT ON
	SELECT c.FName + ' ' + c.MName + ' ' + c.LName Customer, o.OrderDate, p.Name,
	od.Qty, od.Price
	FROM Customers c JOIN Orders o ON c.ID = o.CustomerID AND c.City LIKE @City
	JOIN OrderDetails od ON o.ID = od.OrderID
	JOIN Products p on p.ID = od.ProductID
	WHERE c.LName LIKE @LName
go

