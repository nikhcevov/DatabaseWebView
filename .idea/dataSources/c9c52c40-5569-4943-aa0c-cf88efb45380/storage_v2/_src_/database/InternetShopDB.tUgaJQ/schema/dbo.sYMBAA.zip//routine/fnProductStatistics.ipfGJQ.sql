CREATE FUNCTION fnProductStatistics()
RETURNS table
AS
	RETURN
	(
		SELECT ProductID, SUM(Qty) TotalQty, SUM(TotalPrice) TotalSold, 
		SUM(TotalPrice) / SUM(Qty) AVGPrice
		FROM OrderDetails
		GROUP BY ProductID
	)
go

