

CREATE VIEW dbo.IncomePerDay 
AS
SELECT        SUM(OrderDetails.TotalPrice) AS Income, FORMAT([OrderDate], 'dd/MM/yyyy', 'ru-RU') AS [Date]
FROM            Orders INNER JOIN
                         OrderDetails ON Orders.ID = OrderDetails.OrderID
WHERE         DATEPART(m, OrderDate) = DATEPART(m, DATEADD(m, -1, getdate()))
AND           DATEPART(yyyy, OrderDate) = DATEPART(yyyy, DATEADD(m, -1, getdate()))
GROUP BY      OrderDate
go

