CREATE PROCEDURE spChangeCustomerPhone
	@prev_phone CHAR(12),
	@new_phone CHAR(12)
AS
	SET NOCOUNT ON
	BEGIN
		UPDATE Customers 
		SET Phone = @new_phone 
		WHERE Phone = @prev_phone
	END
go

