

CREATE VIEW dbo.IncomePerMonth
AS
SELECT        SUM(OrderDetails.TotalPrice) AS Income, FORMAT([OrderDate], 'MM/yyyy', 'ru-RU') AS [Date]
FROM            Orders INNER JOIN
                         OrderDetails ON Orders.ID = OrderDetails.OrderID
WHERE         DATEPART(yyyy, OrderDate) = DATEPART(yyyy, DATEADD(y, 0, getdate()))
GROUP BY      FORMAT([OrderDate], 'MM/yyyy', 'ru-RU')
go

