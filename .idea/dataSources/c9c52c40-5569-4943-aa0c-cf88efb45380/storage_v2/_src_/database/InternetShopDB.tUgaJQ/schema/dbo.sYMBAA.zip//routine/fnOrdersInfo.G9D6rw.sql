
-- Get sum difference between customers who used employee help and who not in time interval.
CREATE FUNCTION fnOrdersInfo (@DateFrom date, @DateTo date)
returns table
AS
RETURN 
(
	SELECT * FROM Orders JOIN 
				OrderDetails
				ON OrderID = ID
			WHERE OrderDate BETWEEN @DateFrom AND @DateTo
)
go

